import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/helpers/validation_helper.dart';
import '../../core/helpers/snackbar_helper.dart';
import '../../core/routes/app_router.dart';
import '../../core/errors/app_exceptions.dart';
import '../../data/models/user_model.dart';
import '../../data/repositories/auth_repository.dart';
import '../../shared/widgets/custom_text_field.dart';
import '../../shared/widgets/gradient_button.dart';

/// Screen for new users to register.
class RegisterScreen extends ConsumerStatefulWidget {
  const RegisterScreen({super.key});

  @override
  ConsumerState<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmController = TextEditingController();

  final _nameFocus = FocusNode();
  final _emailFocus = FocusNode();
  final _phoneFocus = FocusNode();
  final _passwordFocus = FocusNode();
  final _confirmFocus = FocusNode();

  bool _isLoading = false;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    _confirmController.dispose();
    _nameFocus.dispose();
    _emailFocus.dispose();
    _phoneFocus.dispose();
    _passwordFocus.dispose();
    _confirmFocus.dispose();
    super.dispose();
  }

  Future<void> _handleRegister() async {
    // Dismiss soft keyboard
    FocusScope.of(context).unfocus();

    if (_formKey.currentState!.validate()) {
      setState(() => _isLoading = true);

      final user = UserModel(
        fullName: _nameController.text.trim(),
        email: _emailController.text.trim(),
        phoneNumber: _phoneController.text.trim(),
        password: _passwordController.text,
      );

      try {
        await ref.read(authRepositoryProvider).register(user);

        if (!mounted) return;
        setState(() => _isLoading = false);

        MessageHelper.showSuccess(context, 'Registration successful!');
        context.go(AppRouter.setupSim);
      } on AppException catch (e) {
        if (!mounted) return;
        setState(() => _isLoading = false);
        MessageHelper.showError(context, e.message);
      } catch (e) {
        if (!mounted) return;
        setState(() => _isLoading = false);
        MessageHelper.showError(context, 'Registration failed: ${e.toString()}');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => FocusScope.of(context).unfocus(),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: AutofillGroup(
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 20),
                    const Text(
                      'Create Account',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Join SMSMitra and start sending messages!',
                      style: TextStyle(color: Colors.grey),
                    ),
                    const SizedBox(height: 32),

                    CustomTextField(
                      label: 'Full Name',
                      hint: 'Enter your full name',
                      icon: Icons.person_outline,
                      controller: _nameController,
                      focusNode: _nameFocus,
                      textInputAction: TextInputAction.next,
                      textCapitalization: TextCapitalization.words,
                      autofillHints: const [AutofillHints.name],
                      validator: ValidationHelper.validateName,
                      onFieldSubmitted: (_) => _emailFocus.requestFocus(),
                    ),

                    CustomTextField(
                      label: 'Email Address',
                      hint: 'Enter your email',
                      icon: Icons.email_outlined,
                      controller: _emailController,
                      focusNode: _emailFocus,
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      autofillHints: const [AutofillHints.email],
                      validator: ValidationHelper.validateEmail,
                      onFieldSubmitted: (_) => _phoneFocus.requestFocus(),
                    ),

                    CustomTextField(
                      label: 'Phone Number',
                      hint: 'Enter 10-digit mobile number',
                      icon: Icons.phone_android_outlined,
                      controller: _phoneController,
                      focusNode: _phoneFocus,
                      keyboardType: TextInputType.phone,
                      textInputAction: TextInputAction.next,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(10),
                      ],
                      autofillHints: const [AutofillHints.telephoneNumber],
                      validator: ValidationHelper.validatePhone,
                      onFieldSubmitted: (_) => _passwordFocus.requestFocus(),
                    ),

                    CustomTextField(
                      label: 'Password',
                      hint: 'Enter password (min 6 characters)',
                      icon: Icons.lock_outline,
                      controller: _passwordController,
                      focusNode: _passwordFocus,
                      isPassword: true,
                      textInputAction: TextInputAction.next,
                      autofillHints: const [AutofillHints.newPassword],
                      validator: ValidationHelper.validatePassword,
                      onFieldSubmitted: (_) => _confirmFocus.requestFocus(),
                    ),

                    CustomTextField(
                      label: 'Confirm Password',
                      hint: 'Confirm your password',
                      icon: Icons.lock_reset_outlined,
                      controller: _confirmController,
                      focusNode: _confirmFocus,
                      isPassword: true,
                      textInputAction: TextInputAction.done,
                      autofillHints: const [AutofillHints.newPassword],
                      validator: (val) => ValidationHelper.validateConfirmPassword(
                        val,
                        _passwordController.text,
                      ),
                      onFieldSubmitted: (_) => _handleRegister(),
                    ),

                    const SizedBox(height: 12),
                    GradientButton(
                      text: 'Register Now',
                      onPressed: _handleRegister,
                      isLoading: _isLoading,
                    ),

                    const SizedBox(height: 24),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text("Already have an account? "),
                        GestureDetector(
                          onTap: () => context.go(AppRouter.login),
                          child: const Text(
                            'Login',
                            style: TextStyle(
                              color: Colors.orange,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
